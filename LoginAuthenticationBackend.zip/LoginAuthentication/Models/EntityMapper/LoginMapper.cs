using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using LoginAuthentication.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoginAuthentication.Models.EntityMapper
{
    public class LoginMapper:AbstractValidator<Login>
    {
          public LoginMapper(EntityTypeBuilder<Login> builder)
        {
            builder.Property(t=>t.Id).ValueGeneratedOnAdd(); //Auto Generate Id
        }
    }
}