using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LoginAuthentication.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace LoginAuthentication.Models.EntityMapper
{
    public class RegisterMapper
    {
          public RegisterMapper(EntityTypeBuilder<Register> builder)
        {
            builder.HasKey(t=>t.Email); //Primary Key
            
            builder.Property(t=>t.Name).IsRequired();
            builder.Property(t=>t.Password).IsRequired();
        }
    }
}