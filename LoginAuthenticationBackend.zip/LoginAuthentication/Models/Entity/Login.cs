using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginAuthentication.Models.Entity
{
    public class Login
    {
         public int Id{get;set;}
        public string Email{get;set;}
        public byte[]? password{get;set;}
        public byte[]? salt{get;set;}    //used for storing encrypted password
        public DateTime LoginTime{get;set;}
    }
}