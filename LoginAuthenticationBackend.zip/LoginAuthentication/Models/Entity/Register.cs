using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoginAuthentication.Models.Entity
{
    public class Register
    {
        public string Name{get;set;}
        public long phone{get;set;}
        public string Email{get;set;}
        public byte[]? Password { get; set; }
        public byte[]? Salt { get; set; }    //used for storing encrypted password
        public int AttemptNo{get;set;}
        public DateTime LoginTime{get;set;}
        // public Boolean IsLocked{get;set;}
    }
}