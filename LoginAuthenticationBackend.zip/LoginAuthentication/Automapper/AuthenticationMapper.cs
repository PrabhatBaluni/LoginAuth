using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text;
using AutoMapper;
using LoginAuthentication.DTO;
using LoginAuthentication.Models.Entity;

namespace LoginAuthentication.Automapper
{
    public class AuthenticationMapper:Profile
    {
        public AuthenticationMapper()
        {
            CreateMap<LoginDto,Login>();
            CreateMap<RegisterDto,Register>()
            .ForMember(dest => dest.Password, opt => opt.MapFrom(src => Encoding.ASCII.GetBytes(src.password)));
        }
    }
}