using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LoginAuthentication.Models.Entity;
using LoginAuthentication.Models.EntityMapper;
using Microsoft.EntityFrameworkCore;

namespace LoginAuthentication.Database
{
    public class AuthenticationDbContext:DbContext
    {
         // Dbset used for creating Table in Database
        public DbSet<Register> register{get;set;} 
        public DbSet<Login> login{get;set;}

        // Applying Constructor Chaining
        public AuthenticationDbContext(DbContextOptions options):base(options) 
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            new RegisterMapper(modelBuilder.Entity<Register>());
        }
    }
}