using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LoginAuthentication.Models.Entity;

namespace LoginAuthentication.Services
{
    public interface IAuthenticationRepository
    {
        Register Register(Register user, string password);
        UserModel UserLogin(string Email, string Password);
        Register UserNotFound(string Email);
        bool UserExists(string email);
        (string, int) CheckingPassword(string password, byte[] passwordHash, byte[] salt, Register Userdata);
        string ResetPassword(string Email, string password);
        string SendMail(string url, string Email);
        // string GenerateToken(string email, TimeSpan expiration);

    }
}