using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LoginAuthentication.Models.Entity;
using LoginAuthentication.DTO;
using LoginAuthentication.Database;
using System.Text;
using RestSharp;
using RestSharp.Authenticators;
using System.Net.Mail;
using System.Net;
using Microsoft.Extensions.Options;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;

namespace LoginAuthentication.Services
{
    public class AuthenticationRepository : IAuthenticationRepository
    {
         private readonly AuthenticationDbContext db;
         private readonly IConfiguration config;
         private readonly ISendGridClient sendGridClient;
          
         public AuthenticationRepository(AuthenticationDbContext _db,ISendGridClient _sendGridClient,IConfiguration _configuration)
         {
            db = _db;
            sendGridClient = _sendGridClient;
            config = _configuration;
         }
  
        public Register UserNotFound(string Email)
        {
            var user = db.register.FirstOrDefault(x => x.Email == Email);    
            return user;
        }

        //function for Encrypting password by hashing algorithm SHA512
        private void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] salt)
        {
            using (var hmac = new System.Security.Cryptography.HMACSHA512())
            {
                salt = hmac.Key;
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }

        // verify input password by comparing with hashpassword stored in database
        private bool VerifyPasswordHash(string password, byte[] passwordHash, byte[] salt)
        {
            using (var hmac = new System.Security.Cryptography.HMACSHA512(salt))
            {
                var computedHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                for (int i = 0; i < computedHash.Length; i++)
                {
                    if (computedHash[i] != passwordHash[i]) return false;
                }
            }
            return true;
        }

        //Register User
        public Register Register(Register user, string password)
        {
            byte[] passwordHash, salt;
            CreatePasswordHash(password, out passwordHash, out salt); //Encrypt password 
         
            user.Password = passwordHash;
            user.Salt = salt;

            db.register.Add(user);
            db.SaveChanges();



            return user;
        }

        public bool UserExists(string email)
        {
            if (db.register.Any(x => x.Email == email))
                return true;
            return false;
        }

      
         public Login createLogs(string email, DateTime loginTime)
{
    Login log = new Login();
   
       log. Email = email;
        log.LoginTime = loginTime.ToUniversalTime();
   
    return log;
}


        public bool DateTimeCheck(Register user)
        {

            if ((user.LoginTime.Day) != (System.DateTime.Now).Day)
            {
                return true;
            }
            else
            {
                if (((user.LoginTime.Hour) * 60 + user.LoginTime.Minute + ((user.LoginTime.Second) / 60) + 30) <= ((System.DateTime.Now).Hour) * 60 + (System.DateTime.Now).Minute + (((System.DateTime.Now).Second) / 60))
                    return true;
                else
                    return false;
            }
        }

        public bool resetUserAttempt(Register Userdata)
        {
            if (DateTimeCheck(Userdata))
            {
                Userdata.AttemptNo = 0;
          
                Userdata.LoginTime = Convert.ToDateTime("0001-01-01 00:00:00");
         
                db.Update(Userdata);
                db.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        
    

       


public (string, int) CheckingPassword(string password, byte[] passwordHash, byte[] salt, Register Userdata)
{   
    if (VerifyPasswordHash(password, Userdata.Password, Userdata.Salt)&&Userdata.LoginTime.ToString()=="01-01-0001 00:00:00")
    {
        var nAttempt = Userdata.AttemptNo;
        if (nAttempt < 5)
        {
            Userdata.AttemptNo = 0;
            Userdata.LoginTime = DateTime.MinValue.ToUniversalTime(); // Set to UTC minimum value
            db.Update(Userdata);
            db.SaveChanges();
            return ("201", 0);
        }
        else
        {
            if (resetUserAttempt(Userdata))
            {
                return ("201", 0);
            }
            else
            {
                return ("203", 0);
            }
        }
    }
    else
    {
        int nAttempt = Userdata.AttemptNo;
        int AllowAttempt = 5;
        if (nAttempt < 3)
        {
            Userdata.AttemptNo++;
            db.login.Add(createLogs(Userdata.Email, DateTime.UtcNow)); // Store UTC DateTime
            db.SaveChanges();
            nAttempt = Userdata.AttemptNo;
            return ($"Invalid Credentials!! {AllowAttempt - nAttempt} Attempt Remaining", nAttempt);
        }
        if (nAttempt == 3)
        {
            Userdata.AttemptNo++;
            db.login.Add(createLogs(Userdata.Email, DateTime.UtcNow)); // Store UTC DateTime
            db.SaveChanges();
            return ("Invalid Credentials!! This is your Final Attempt!", nAttempt);
        }
        if (nAttempt == 4)
        {
            Userdata.AttemptNo++;
            Userdata.LoginTime = DateTime.UtcNow; // Store UTC DateTime
            db.login.Add(createLogs(Userdata.Email, DateTime.UtcNow)); // Store UTC DateTime
            db.SaveChanges();
            return ("203", 0);
        }
        else
        {
            // Check if the user is blocked
            int elapsedTime = Convert.ToInt32(DateTime.UtcNow.Minute)- Convert.ToInt32(Userdata.LoginTime.Minute);
            if (elapsedTime < 1)
            {
                return ("203 blocked for an hour", 0);
            }
            else
            {
                // Reset the attempt count and login time
                Userdata.AttemptNo = 0;
                Userdata.LoginTime = DateTime.MinValue.ToUniversalTime();
                db.Update(Userdata);
                db.SaveChanges();
                return ("201", 0);
            }
        }
    }
}


        

        public string ResetPassword(string email,string password)
        {
            ResetPassword reset = new ResetPassword();
            reset.Email = email;
            reset.password = password ;
            
            var user = db.register.FirstOrDefault(t => t.Email == email);
            reset.Email = user.Email;
            
            if(UserExists(email))
            {
               // user.Password = Encoding.ASCII.GetBytes(password); 
                byte[] passwordHash, salt;
                CreatePasswordHash(password, out passwordHash, out salt); //Encode
                user.Password = passwordHash;
                user.Salt = salt;
                db.register.Update(user);
                db.SaveChanges();
                return "Password Changed Successfully";
            }
            else
                return "Enter valid Email!!!";
        }

        UserModel IAuthenticationRepository.UserLogin(string Email, string Password)
        { 
            var userData = UserNotFound(Email);
            var userModel=new UserModel();
            if (userData == null)
            {
                userModel.ResponseCode="202";
                return userModel;
            }
            else
            {
              
                (var verifiedPassword,var attempCount )= CheckingPassword(Password, userData.Password, userData.Salt, userData);
                 userModel.Email=Email;
                 userModel.AttempCount=attempCount;
                 userModel.ResponseCode=verifiedPassword;
           
                  return userModel;
            }
        }


         public string SendMail(string url, string Email)
        {
            string fromEmail = config.GetSection("EmailSettings").GetValue<string>("SenderEmail");
            string fromName = config.GetSection("EmailSettings").GetValue<string>("SenderName");
            string apk = config.GetSection("EmailSettings").GetValue<string>("ApiKey");

           
            var msg = new SendGridMessage()
            {
                From = new EmailAddress(fromEmail, fromName),
                Subject = "Reset Link",
                PlainTextContent = url
            };
            msg.AddTo(Email);
            var response = sendGridClient.SendEmailAsync(msg);
           
            return "send successfully";

           
        }

       
    }

      
    }
