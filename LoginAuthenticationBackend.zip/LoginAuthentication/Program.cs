using System.Text;
using AutoMapper;
using LoginAuthentication.Database;
using LoginAuthentication.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using SendGrid.Extensions.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddDbContext<AuthenticationDbContext>(t=>t.UseNpgsql(builder.Configuration.GetConnectionString("PostgresqlConnection")));
builder.Services.AddTransient<IAuthenticationRepository,AuthenticationRepository>();

builder.Services.AddSendGrid(options =>
{
    options.ApiKey = builder.Configuration.GetSection("EmailSettings").GetValue<string>("ApiKey");
});

builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors();






//validate Token here by using this

// builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)

//  .AddJwtBearer(options => {

//  options.TokenValidationParameters = new TokenValidationParameters
//  {

//  ValidateIssuerSigningKey = true,

//  IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII

//  .GetBytes(builder.Configuration.GetSection("AppSettings:Token").Value)),

//  ValidateIssuer = false,

//  ValidateAudience = false

// };

//  });







var app = builder.Build();

app.UseStaticFiles(new StaticFileOptions()
{
    OnPrepareResponse = context =>
    {
        context.Context.Response.Headers.Add("Cache-Control", "no-cache, no-store");
        context.Context.Response.Headers.Add("Expires", "-1");
    }
});

app.UseCors(x => x
.AllowAnyMethod()
.AllowAnyHeader()
.SetIsOriginAllowed(origin => true)
.AllowCredentials());

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// app.UseAuthentication();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
