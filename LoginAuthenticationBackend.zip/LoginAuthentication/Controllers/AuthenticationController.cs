
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using AutoMapper;
using LoginAuthentication.DTO;
using LoginAuthentication.Models.Entity;
using LoginAuthentication.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.IdentityModel.Tokens;

namespace LoginAuthentication.Controllers
{  
    [ApiController]
    [Route("api/[controller]")]

[ResponseCache(Location = ResponseCacheLocation.None, Duration = 0, NoStore = true)]
    public class AuthenticationController : ControllerBase
    {
       private readonly IAuthenticationRepository authRepository;
        private readonly IMapper mapper;

        public AuthenticationController(IAuthenticationRepository _authRepository,IMapper _mapper)
        {
            authRepository = _authRepository;
            mapper = _mapper;
        }
         [HttpPost("register")]
        [ResponseCache(Location = ResponseCacheLocation.None, Duration = 0, NoStore = true)]
        public IActionResult Register(RegisterDto authDTO)
        {
            authDTO.Email = authDTO.Email.ToLower();
            if (authRepository.UserExists(authDTO.Email))

                return BadRequest("Email already exists");

            var userToCreate = mapper.Map<Register>(authDTO);
            var createdUser = authRepository.Register(userToCreate, authDTO.password);
           
            return StatusCode(201, new { email = createdUser.Email, Name = createdUser.Name });
        }
        [HttpPost("login")]
        [ResponseCache(Location = ResponseCacheLocation.None, Duration = 0, NoStore = true)]
        public IActionResult Login(LoginDto loginDTO)
        {
           var userRecord = authRepository.UserLogin(loginDTO.Email.ToLower(), loginDTO.password);
            return Ok(userRecord);
        }

        
        [HttpPost("ResetPassword")]
                [ResponseCache(Location = ResponseCacheLocation.None, Duration = 0, NoStore = true)]

        public IActionResult ResetPassword(ResetPassword resetPassword)
        {
            var userReset = authRepository.ResetPassword(resetPassword.Email,resetPassword.password);
            return Ok(userReset);
        }
        
        [HttpGet("sendResetLink")]
                [ResponseCache(Location = ResponseCacheLocation.None, Duration = 0, NoStore = true)]
        public bool sendResetLink(string Email)
        {
            var currentTime = DateTime.Now;
            var userFromRepository = authRepository.UserExists(Email);
             if (userFromRepository == false)
                 return false;
             else
            {
                var Url = "http://localhost:4200/ResetPassword?currentTime="+currentTime.Hour+':'+currentTime.Minute+':'+currentTime.Second;
                authRepository.SendMail(Url, Email);
                return true;
            }
        }
        
       
//   [HttpGet("sendResetLink")]
// public bool SendResetLink(string email)
// {
//     var userFromRepository = authRepository.UserExists(email);
//     if (!userFromRepository)
//         return false;
    
//     var token = authRepository.GenerateToken(email, TimeSpan.FromHours(1)); // Generate a token with 1-hour expiration
//     var url = $"http://localhost:4200/ResetPassword?token={token}";
    
//     authRepository.SendMail(url, email);
//     return true;
// }

}
}
