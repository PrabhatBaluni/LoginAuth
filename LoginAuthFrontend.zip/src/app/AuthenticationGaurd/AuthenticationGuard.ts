import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../Service/AuthenticationService';

@Injectable()
export class AuthGuard implements CanActivate {
    constructor(private authenticationService:AuthService,private myRouter:Router) { }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        if(this.authenticationService.RegisteredIn())
        {
         
           return true;
        }
        else
        {
            this.myRouter.navigate(['/SignIn']);
            return false;
        }
    }
}    