import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthService } from './Service/AuthenticationService';
import { AuthGuard } from './AuthenticationGaurd/AuthenticationGuard';
import { RouterModule } from '@angular/router';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';


import { SocialLoginModule, SocialAuthServiceConfig, FacebookLoginProvider } from '@abacritt/angularx-social-login';
import { GoogleLoginProvider} from '@abacritt/angularx-social-login';
import {  GoogleSigninButtonModule } from '@abacritt/angularx-social-login';
import { GoogleComponent } from './google/google.component';
import { LinkedinComponent } from './linkedin/linkedin.component';



@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    HomeComponent,
    ForgetPasswordComponent,
    ResetPasswordComponent,
    GoogleComponent,
    LinkedinComponent
  ],
  imports: [
    BrowserModule,ReactiveFormsModule,RouterModule,BrowserAnimationsModule,
    HttpClientModule,FormsModule,AppRoutingModule,ToastrModule.forRoot(),
    SocialLoginModule,GoogleSigninButtonModule,CommonModule
  ],
  providers: [RegisterComponent, AuthGuard, AuthService,
    LoginComponent,
    HomeComponent,

    {
      provide: 'SocialAuthServiceConfig',
      useValue: {
        autoLogin: false,
        providers: [
           {
             id: GoogleLoginProvider.PROVIDER_ID,
             provider: new GoogleLoginProvider(
               '75681122569-o3ebk4kkin8fl3shfrilqg11vkfbt4tr.apps.googleusercontent.com'
             )
           },
          {
            id: FacebookLoginProvider.PROVIDER_ID,
            provider: new FacebookLoginProvider('261758576302844')
          }
        ],
        onError: (err) => {
          console.error(err);
        }
      } as SocialAuthServiceConfig,
    },
    { provide: 'apiKey', useValue: '775lgcs2o4rsdo' },

    { provide: 'authorize', useValue: 'true/false' }, // OPTIONAL by default: false

    { provide: 'isServer', useValue: 'true/false' } 
  
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }
