import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable()
export class AuthService {

   // registerUrl: any = 'http://localhost:5140/api/Authentication/register';
   registerUrl: any ='http://localhost:5125/api/Authentication/register';
   // loginUrl: any = 'http://localhost:5140/api/Authentication/Login';
   loginUrl: any ='http://localhost:5125/api/Authentication/login';
   // ResetPasswordUrl: any='http://localhost:5140/api/Authentication/ResetPassword';
   ResetPasswordUrl: any= 'http://localhost:5125/api/Authentication/ResetPassword';
   ForgotPasswordUrl :any = 'http://localhost:5125/api/Authentication/sendResetLink';
 
    constructor(private httpClient: HttpClient) {
    }

    createAccount(register:any):Observable<any>{
        return this.httpClient.post<any>(this.registerUrl,register);
    }

    LoginAccount(login:any):Observable<any>{
        return this.httpClient.post<any>(this.loginUrl,login);
    }
    RegisteredIn()
    {
        return localStorage.getItem("myUser");
    }

    
    loginStatus():any
    {
        console.log(localStorage.getItem('myUser'));
        return localStorage.getItem('myUser'); 
    }

    linkValidators(data:any):Observable<any>
    {
        // console.log(data);
        return this.httpClient.post(this.ResetPasswordUrl,data,{responseType:'text'});
    }

    forgotPassword(email:any):Observable<any>{
        const params = new HttpParams({
            fromString: `Email=${email}`
          });
          let getDats = this.httpClient.get(this.ForgotPasswordUrl, { params ,responseType:'text'});
          return getDats;
    }

}
