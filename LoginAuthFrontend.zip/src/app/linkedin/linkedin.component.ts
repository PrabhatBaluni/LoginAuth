import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-linkedin',
  templateUrl: './linkedin.component.html',
  styleUrls: ['./linkedin.component.css']
})
export class LinkedinComponent implements OnInit{

  linkedInToken = "";

 

  constructor(private route: ActivatedRoute) {}

 

  ngOnInit() {

    this.linkedInToken = this.route.snapshot.queryParams["code"];

  }

}
