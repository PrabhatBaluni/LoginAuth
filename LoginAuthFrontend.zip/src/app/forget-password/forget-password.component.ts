import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../Service/AuthenticationService';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent implements OnInit {

  signUpForm: any;
  user: any;
  isShown = false;

  constructor(public formBuilder: FormBuilder, private authService: AuthService, private myRouter: Router) { }

  get getControl() {
    return this.signUpForm.controls;
  }

  ngOnInit(): void {
    this.signUpForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]]
    })

  }

  onSubmit() {
    this.user = this.signUpForm.value;
    this.authService.forgotPassword(this.user.email).subscribe(res => {
    if(res == "true"){
    // this.myRouter.navigate(["/ResetPassword"]);
      
      console.log('mail sent')
      this.isShown = true;

    }
   
  }
  ,error=>{
     console.log(error);
    alert("user not Found");
  })

}
}
