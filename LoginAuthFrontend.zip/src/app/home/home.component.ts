import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  email:any;
  loggedin:any;
  myUser:any;
  constructor(private myRouter:Router)
  {

  }

  ngOnInit()
  {
    // console.log(localStorage.getItem('myUser'));
    this.email=localStorage.getItem('myUser');
    if(localStorage.getItem("myUser")){
      this.loggedin='true';
    }else{
      this.loggedin='false';
    }
  }
  RemoveUser():void
  {
    localStorage.removeItem("email");
    localStorage.removeItem("myUser");
      this.myRouter.navigate(['SignIn']);

      this.loggedin='false';
  }

}
