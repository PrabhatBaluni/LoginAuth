import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../Service/AuthenticationService';
import { ActivatedRoute, Router } from '@angular/router';
import Validation from '../Validation';
import { ToastrService } from 'ngx-toastr';
import { windowWhen } from 'rxjs';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  Email: any;
  form: FormGroup = new FormGroup({
    email: new FormControl(''),
    password: new FormControl(''),
    confirmPassword: new FormControl(''),
  });
  submitted = false;
  minuteDifference: any;
  constructor(private formBuilder: FormBuilder, private authService: AuthService, private myRoute: Router, private activatedRoute: ActivatedRoute, private toastr: ToastrService,) { }

  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  ngOnInit(): void {
    this.Email = this.activatedRoute.snapshot.paramMap.get("Email");
    let paramDate = window.location.href.split('=')[1]
    let currentDate;
    currentDate = new Date().getHours()+':'+new Date().getMinutes()+':'+new Date().getSeconds();

    if(paramDate!.split(':')[0]==new Date().getHours().toString()){
      this.minuteDifference=parseInt(new Date().getMinutes().toString())-parseInt(paramDate!.split(':')[1]);
    }
    this.form = this.formBuilder.group(
      {
        email: ['', [Validators.required, Validators.email]],
        password: [
          '',
          [
            Validators.required,
            Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{8,}$')
          ]
        ],
        confirmPassword: ['', Validators.required]
      },
      {
        validators: [Validation.match('Password', 'confirmPassword')]
      }
    );
  }


  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }
  onSubmit(form: any): void {
    this.submitted = true;
    console.log(this.form.value);
    if (this.form.value.password !== this.form.value.confirmPassword) {
      this.toastr.error("Invalid Email & Password");
      return;}
    this.authService.linkValidators(form).subscribe(res => {
      if (res == "Password Changed Successfully") {
        console.log(res);
        this.myRoute.navigate(['/SignIn']);
        alert(res);
      }
      else
        alert(res);
    }, err => {
      alert("Enter valid Email!!!")
    });
    if (this.form.invalid) {
      return;
    }
       
  }
}

