export class UserModel
{
    ResponseCode?:any;
    Email?:string;
    AttempCount?:number;
}