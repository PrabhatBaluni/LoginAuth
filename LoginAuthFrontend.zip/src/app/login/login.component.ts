import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../Service/AuthenticationService';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FacebookLoginProvider, GoogleLoginProvider, SocialAuthService } from '@abacritt/angularx-social-login';
import { gapi } from 'gapi-script';
import { UserModel } from '../UserModel';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  
 

  result:any;

  signUpForm: any;
  Data: any;
  temp: any = [];
  googleUser: any;
  googleLoginOptions = {

    scope: 'profile email'

  };

  userForm: FormGroup;
  user :any;
  loggedIn: any;

 
  constructor(private formBuilder:FormBuilder,private toastr: ToastrService,private authenticationService: AuthService,private myRouter:Router,private gauthService: SocialAuthService)
  {
    this.userForm=formBuilder.group({
      email:["",[Validators.required, Validators.email]],
      password:["",[Validators.required]] 
    });

  }
  
  loginUserData ={
    'Email':'',
    'Password':''
  };
  get f() { return this.userForm.controls; } 

 
         
          LoginData(dex: any): void {
            this.authenticationService.LoginAccount(this.userForm.value).subscribe({
                next: result => {
                   console.log(result.responseCode);
                 
                 
                    if (result.responseCode != "201") {
                        console.log(Error);
                      //  this.toastr.error("Invalid Email & Password");
                        this.toastr.error(result.responseCode);
                    } else {
                        this.toastr.success("Login successfully !!");
                        console.log(result.email);
                        localStorage.setItem('myUser', result.email);
                        this.myRouter.navigate(['Home']);
                    }
                },
                error: error => {
                    console.log(error); // This error is given by the service login function
                    this.toastr.error("Invalid Email & Password");
                }
            });
        }
        

          //facebook
          signInWithFB(): void {
            this.gauthService.signIn(FacebookLoginProvider.PROVIDER_ID).then((data) =>{

              console.log(data);
                this.myRouter.navigate(["/Home"]);
            }).catch(data=>{
              this.gauthService.signOut();
            })
          }

          signInWithG(): void
          {
            this.myRouter.navigate(['Google']);
          }

          //Linkedin
          linkedInCredentials = {

            clientId: "775lgcs2o4rsdo",
        
            redirectUrl: "https://localhost:4200/Home",
        
            scope: "r_liteprofile%20r_emailaddress%20w_member_social" // To read basic user profile data and email
        
          };
          loginwithLinkedin() {
            window.location.href = `https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id=${
        
              this.linkedInCredentials.clientId
        
            }&redirect_uri=${this.linkedInCredentials.redirectUrl}&scope=${this.linkedInCredentials.scope}`;
          }
            

         

          get getControl(): any {
            return this.userForm.controls;
          }
}
