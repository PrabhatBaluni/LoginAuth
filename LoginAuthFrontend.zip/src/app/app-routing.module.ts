import { RouterModule, Routes } from "@angular/router";
import { RegisterComponent } from "./register/register.component";
import { LoginComponent } from "./login/login.component";
import { HomeComponent } from "./home/home.component";
import { NgModule } from "@angular/core";
import { AuthGuard } from "./AuthenticationGaurd/AuthenticationGuard";
import { ResetPasswordComponent } from "./reset-password/reset-password.component";
import { GoogleComponent } from "./google/google.component";
import { ForgetPasswordComponent } from "./forget-password/forget-password.component";

const MyRoute: Routes =  // We are making a route table using the Routes class.
  [
    { path: 'Signup', component: RegisterComponent },
    { path: 'SignIn', component: LoginComponent },
    { path: 'Home', component: HomeComponent,},
    { path: 'ResetPassword', component:ResetPasswordComponent},
    { path:'forgotpassword', component: ForgetPasswordComponent},
    { path: 'Google', component:GoogleComponent},
    { path: '', component: LoginComponent, canActivate: [AuthGuard]},
   // { path:'forgotpassword', component: ForgotPasswordComponent},
   // { path: '', component: LoginComponent},
    { path: '', component: RegisterComponent,pathMatch:'full'}
  ]

@NgModule({
  imports: [RouterModule.forRoot(MyRoute)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
