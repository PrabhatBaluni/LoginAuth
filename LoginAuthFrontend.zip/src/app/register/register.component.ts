import { Component } from '@angular/core';
import { AbstractControl, EmailValidator, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../Service/AuthenticationService';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  form: FormGroup = new FormGroup({
    Name: new FormControl(''),
    Email: new FormControl(''),
    Phone: new FormControl(''),
    Password: new FormControl(''),
    confirmPassword: new FormControl(''),
  });
  submitted = false;
  constructor(private myRouter:Router,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private authenticationService:AuthService ) {}

  keyPress(event: any) 
  {
    const pattern = /[0-9\+\-\ ]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  ngOnInit(): void 
  {
    this.form = this.formBuilder.group(
      {
        Name: [
          '',
          [
            Validators.required,
            Validators.minLength(2),
            Validators.maxLength(20)
          ]
        ],
        Email: ['', [Validators.email]],
        Phone: ['', [ Validators.required,
          Validators.pattern("^[0-9]*$"),
          Validators.minLength(10), Validators.maxLength(10)]],
        Password: [
          '',
          
            Validators.required,
            Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{8,}$')
          
        ],
        confirmPassword: ['', Validators.required]
      },
     
    );
  }


  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }
 
 

  onSubmit(temp: any): void {
    this.submitted = true;
    console.log(this.form.value);
  
    if (this.form.value.Password !== this.form.value.confirmPassword) {
      this.toastr.error("Invalid Email & Password");
      return;
    }
  
    // Email validation check
    const emailPattern = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
    const email = this.form.value.Email;
  
    if (!emailPattern.test(email)) {
      this.toastr.error("Invalid email");
      return;
    }
  
    // Phone number validation check
    const phoneNumberPattern = /^\d{10}$/;
    const phoneNumber = this.form.value.Phone;
  
    if (!phoneNumberPattern.test(phoneNumber)) {
      this.toastr.error("Invalid phone number");
      return;
    }
  
    this.authenticationService.createAccount(this.form.value).subscribe({
      next: result => {
        console.log(result);
        this.myRouter.navigate(['SignIn']);
      },
      error: error => {
        console.log(error);
      }
    });
  }
  
  


  clicksub()
  {
    console.log(this.form.value);
    this.form.reset;
    
  } 
}
